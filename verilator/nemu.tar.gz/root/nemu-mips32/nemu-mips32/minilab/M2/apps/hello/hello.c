#include <stdio.h>

int main() {
  printf("Hello, njumips world\n");
  return 0;
}
