void init_ram(const char* coe_file);
