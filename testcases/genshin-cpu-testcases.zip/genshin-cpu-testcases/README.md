# 测例的文档

修改和注释了原有的指令测试集合（insttest 70个点以后），这些指令目前都用不到，但是只是注释了里面的指令，以后方便增加新的集合。

7月21日的测例已经通过UCAS2019的核生成了trace。

```shell
#记得输入环境变量
export MIPS_TEST_HOME=/root/mipstest
```



## (原说明)mipstest

introduction:
1. insttest
    * test basic instructions (mips32r1 and mips32r2)
2. extest
    * test exception implementation
3. tlbtest
    * test mmu (always assume 32 tlb entries)
4. intrtest
    * test timer interrupt (especially occurred in delayslot or exception)
5. fputest
    * test fpu instructions

migrate notes:

1. All testcases will be loaded into 0xBFC00000 - 0xBFCFFFFF.
2. When encounter test failure, framework will write 1 to 0xB0000000
3. After passing all testcases, value 0 will be written to 0xB0000000



